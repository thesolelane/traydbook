# Protected Super Admin Snippet

## What this does
Locks one email address as the permanent super admin of your app.
Nobody can demote, ban, suspend, or change the role of this account
through the admin panel — even other admins.

## Files
- server/lib/auth.js         — middleware with blockProtectedAdmin + isProtectedAdmin
- supabase/protect_super_admin.sql — DB trigger + role setup (run in Supabase SQL editor)

## Setup for a new app

1. Set this environment variable (never hardcode the email):
   PROTECTED_SUPER_ADMIN_EMAIL=your@email.com

2. In server/lib/auth.js, import and use blockProtectedAdmin as middleware
   on any route that can change a user's role, suspend, or ban:
   router.patch('/role', requireAuth, requireAdminLevel, blockProtectedAdmin, handler)

3. Run supabase/protect_super_admin.sql in Supabase SQL editor
   (edit the email address in the SQL before running)

## To revoke (Supabase SQL editor only)
   DROP TRIGGER tg_protect_super_admin ON users;
   DROP FUNCTION enforce_protected_super_admin();
