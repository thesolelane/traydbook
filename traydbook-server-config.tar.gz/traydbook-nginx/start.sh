#!/bin/bash
# TraydBook — Build & Start (run once on your server)
# Make executable: chmod +x start.sh

set -e

echo "Installing dependencies..."
npm install

echo "Building frontend..."
npm run build

echo "Starting server..."
NODE_ENV=production node server/index.js
